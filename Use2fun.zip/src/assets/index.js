import userIcon from "./icons/user.png";
import hostIcon from "./icons/host.png";

export { userIcon, hostIcon };
