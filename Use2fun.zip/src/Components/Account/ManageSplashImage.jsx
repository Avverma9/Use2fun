import React from 'react'

const ManageSplashImage = () => {
  return (
    <div>
        <h2>ManageSplashImage</h2>

        <div style={{display:"flex", flexDirection:"column"}}>
            Update Splash Image
            <input type="file" />
        </div>
    </div>
  )
}

export default ManageSplashImage