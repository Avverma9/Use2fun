import React from 'react'

const ManageLength = () => {
  return (
    <div>
        <h2>ManageLength</h2>
        <div>
            Descrpition length
            <select name="" id="">
                <option value="10">10</option>
                <option value="30">30</option>
                <option value="60">60</option>
                <option value="90">90</option>
                <option value="120">120</option>
            </select>
        </div>
    </div>
  )
}

export default ManageLength