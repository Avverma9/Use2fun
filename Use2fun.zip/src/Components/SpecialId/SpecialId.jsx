import React from 'react'

const SpecialIdComp = () => {
  return (
    <div>
        <h2>Special ID</h2>
        <div>
            <p>Special Id</p>
            <input type="text" />
            <button>ADD</button>
        </div>
        <button>CANCEL</button>
        <button>SUBMIT</button>
    </div>
  )
}

export default SpecialIdComp