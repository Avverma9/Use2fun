import React from 'react'

const LockRoom = () => {
  return (
    <div>
        <h2>Lock Room</h2>
        <div>
            <p>Lock Room id</p>
            <input type="text" />
            <button>ADD</button>
        </div>
        <button>CANCEL</button>
        <button>SUBMIT</button>
    </div>
  )
}

export default LockRoom