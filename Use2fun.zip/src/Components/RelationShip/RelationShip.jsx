import React from 'react'

const RelationShip = () => {
  return (
    <div>
        <h2>RelationShip</h2>
        <div>
            <p>Add Relationship</p>
            <input type="text" />
            <button>ADD</button>
        </div>
        <button>CANCEL</button>
        <button>SUBMIT</button>
    </div>
  )
}

export default RelationShip