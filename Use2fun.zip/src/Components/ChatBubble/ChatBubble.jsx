import React from 'react'
import chatBubbleImg from "../../assets/icons/chatbubble1.png"

const ChatBubble = () => {
  return (
    <div>
   <img style={{width:"50%"}} src={chatBubbleImg} alt="" />
    </div>
  )
}

export default ChatBubble