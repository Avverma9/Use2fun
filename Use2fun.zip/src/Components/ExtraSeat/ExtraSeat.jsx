import React from 'react'

const ExtraSeat = () => {
  return (
    <div>
        <h2>ExtraSeat</h2>
        <div>
          <p>ExtraSeat**</p>
            <input type="text" />
            <button>ADD</button>
        </div>
        <button>CANCEL</button>
        <button>SUBMIT</button>
    </div>
  )
}

export default ExtraSeat